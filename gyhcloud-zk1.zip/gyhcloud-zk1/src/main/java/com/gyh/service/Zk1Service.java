package com.gyh.service;

import com.gyh.model.User;

import java.util.List;

public interface Zk1Service {
    List<User> list();
}
