package com.gyh.mapper;

import com.gyh.model.User;

import java.util.List;

public interface Zk1Mapper {

    List<User> list();
}
